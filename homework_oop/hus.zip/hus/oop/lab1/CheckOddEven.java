package hus.oop.lab1;

public class CheckOddEven {
    public static void main(String[] args) {
        int number = -2;
        System.out.println("The number is " + number);
        if (number % 2 == 0) {
            System.out.println("Even Number");
        } else {
            System.out.println("Odd Number");
        }
        System.out.println("Bye!");
    }
}
