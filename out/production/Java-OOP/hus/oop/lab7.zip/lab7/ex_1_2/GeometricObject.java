package hus.oop.lab7.ex_1_2;

public interface GeometricObject {
    double getArea();

    double getPerimeter();

}
