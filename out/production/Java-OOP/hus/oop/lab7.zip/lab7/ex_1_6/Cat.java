package hus.oop.lab7.ex_1_6;

public class Cat extends Animal {

    public Cat(String name) {
        super(name);
    }

    public void greets() {
        System.out.println("Meow");
    }
}
