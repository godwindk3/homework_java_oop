package hus.oop.lab7.ex_1_5;

public interface GeometricObject {
    double getPerimeter();

    double getArea();
}
