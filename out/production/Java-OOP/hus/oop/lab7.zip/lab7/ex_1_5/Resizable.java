package hus.oop.lab7.ex_1_5;

public interface Resizable {
    void resize(int percent);
}
