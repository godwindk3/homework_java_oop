package hus.oop.lab7.ex_1_8;

public interface Movable {
    void moveUp();

    void moveDown();

    void moveLeft();

    void moveRight();

}
