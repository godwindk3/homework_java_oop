package hus.oop.lab7.ex_1_7;

public class Cat extends Animal {
    @Override
    public void greeting() {
        System.out.println("Meow!");
    }

}
