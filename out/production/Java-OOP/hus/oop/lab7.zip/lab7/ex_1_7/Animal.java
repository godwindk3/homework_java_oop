package hus.oop.lab7.ex_1_7;

public abstract class Animal {
    abstract public void greeting();
}
